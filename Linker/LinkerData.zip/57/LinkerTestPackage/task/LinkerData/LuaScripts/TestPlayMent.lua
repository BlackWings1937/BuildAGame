requirePack("baseScripts.homeUI.FrameWork.Global.GlobalFunctions");
local PlayMentBase = requirePack("baseScripts.LinkerBase.PlayMentBase");
print("load--------------------------------------------------------------");
dump(PlayMentBase);

print("load--------------------------------------------------------------2");

local ScriptUtil = requirePack("baseScripts.homeUI.FrameWork.AnimationEngineLua.ScriptUtil");
dump(ScriptUtil);


print("load--------------------------------------------------------------2");
local test = requirePack("baseScripts.LinkerBase.test");
dump(test);



local TestPlayMent = class("TestPlayMent",function()
     return PlayMentBase.new();
end)
g_tConfigTable.CREATE_NEW(TestPlayMent);

function TestPlayMent:Start(rootNode)

    local npc = TouchArmature:create("A",TOUCHARMATURE_NORMAL);

    rootNode:addChild(npc);
    npc:setPosition(cc.p(300,300));

    print("ABCDEFG1234567");
    rootNode:runAction(cc.Sequence:create(cc.DelayTime:create(5),cc.CallFunc:create(function()
        self:SceneEnd("PROT2");
    end)));


end


return TestPlayMent;